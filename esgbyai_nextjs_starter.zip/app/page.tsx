
import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Image from "next/image";

export default function Home() {
  return (
    <main className="min-h-screen bg-white text-gray-900 p-6">
      {/* Hero Section */}
      <section className="text-center py-16 max-w-4xl mx-auto">
        <Image
          src="/logo-full-light.png"
          alt="ESGbyAI Logo"
          width={120}
          height={120}
          className="mx-auto mb-4"
        />
        <h1 className="text-5xl font-bold mb-4">AI-powered ESG, Simplified</h1>
        <p className="text-xl mb-6">
          Automate ESG compliance, reporting, and risk monitoring with one intelligent platform.
        </p>
        <Button className="text-lg px-6 py-3">Try ESGbyAI Free</Button>
      </section>

      {/* Features Section */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 py-12 max-w-6xl mx-auto">
        {[
          { title: "Automated ESG Reports", text: "Generate CSRD, GRI, TCFD-compliant reports from your uploaded data.", icon: "/icon-report.png" },
          { title: "Real-Time ESG Risk Monitor", text: "Scan news and social media for environmental, social, and governance risks.", icon: "/icon-risk.png" },
          { title: "Framework Alignment", text: "Built-in support for global standards like GRI, CSRD, SASB, and more.", icon: "/icon-framework.png" },
          { title: "KPI Dashboard", text: "Track ESG metrics like emissions, diversity, and board composition.", icon: "/icon-dashboard.png" },
          { title: "Predictive ESG Scoring", text: "Benchmark and forecast ESG performance using AI.", icon: "/icon-score.png" },
          { title: "ESG Chat Assistant", text: "Get answers and guidance on ESG frameworks and compliance instantly.", icon: "/icon-chat.png" },
        ].map((feature, index) => (
          <Card key={index}>
            <CardContent className="p-4 text-center">
              <Image
                src={feature.icon}
                alt={feature.title + " icon"}
                width={40}
                height={40}
                className="mx-auto mb-2"
              />
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p>{feature.text}</p>
            </CardContent>
          </Card>
        ))}
      </section>

      {/* Pricing Section */}
      <section className="text-center py-16 max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold mb-4">Pricing Plans</h2>
        <p className="mb-10">Flexible plans for teams of all sizes.</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { title: "Starter", price: "Free", details: ["1 report/month", "Dashboard access", "Manual entry"] },
            { title: "Pro", price: "€49/mo", details: ["Unlimited uploads", "AI-generated reports", "Compliance checker"] },
            { title: "Enterprise", price: "Custom", details: ["White-label", "API access", "Integrations"] },
          ].map((plan, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold mb-2">{plan.title}</h3>
                <p className="text-xl mb-4">{plan.price}</p>
                <ul className="text-left mb-4">
                  {plan.details.map((item, i) => <li key={i}>• {item}</li>)}
                </ul>
                <Button>Get Started</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="text-center py-16">
        <h2 className="text-3xl font-bold mb-4">Start your ESG journey today</h2>
        <Button className="text-lg px-6 py-3">Get Started Free</Button>
      </section>
    </main>
  );
}
